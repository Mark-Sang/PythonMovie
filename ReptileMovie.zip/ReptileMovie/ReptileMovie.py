import requests
import re
import json
from requests.exceptions import RequestException
import os 
import bs4
from bs4 import BeautifulSoup
import os
#正则表达式+requests
def open_url(url):
    try:
        headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36'}
        res = requests.get(url,headers = headers)
        if res.status_code == 200:
            return res
        return None
    except RequestException:
        return None
def find_target(html):
    rank_list = []
    img_list =[]
    actor_list = []
    add_time_list = []
    score_list =[]
    title_list =[]
    soup = BeautifulSoup(html.text,"html.parser")
    rank = soup.find_all("i",class_="board-index")
    img = soup.find_all("img",class_="board-img")
    actor = soup.find_all("p",class_="star")
    add_time = soup.find_all("p",class_="releasetime")
    score = soup.find_all("i",class_="integer")
    title=soup.find_all("a",href=re.compile("/films/"))
    for each in title:

        title_list.append(each.text.strip())
        try :
            title_list.remove("")
        except ValueError:
            pass
    for each in rank :    
        rank_list.append(each.text)
    for each in img:
        img_list.append(str(each).split('="' )[3].split('"/>')[0]) 
    for each in actor:
        actor_list.append(each.text.strip())
    for each in add_time:
        add_time_list.append(each.text)
    for each in score:
        score_list.append(each.string + each.next_sibling.string)
    result = []
    lenth = len(score_list)
    for i in range(lenth):
        result.append("排名第" + rank_list[i] + "   《" + title_list[i] + "》" +  "   评分：" + score_list[i] + "\n"\
                      +actor_list[i] + add_time_list[i] + "\n\n")
    
    return result , img_list,title_list
def save_imgs(imgs_list,titles_list):  
    os.makedirs("imges",exist_ok = True) #创建一个文件夹
    os.chdir("imges") #改变工作目录
    file_name = []
    for each in titles_list:
        file_name.append(each + ".jpg")
    for i,each in enumerate(imgs_list):
        with open(file_name[i],"wb") as f:
                img = open_url(each)
                f.write(img.content)
def save_text(result):
    with open("猫眼TOP100.txt","w") as f:
        for each in result:
            f.write(each)
def main():
    page = 0
    result = []
    imgs_list =[]
    titles_list =[]
    for i in range(2):
        page = i * 10
        url = "http://maoyan.com/board/4?offset=" + str(page)
        html = open_url(url) 
        target_result , img_list ,title_list = find_target(html)
        imgs_list.extend(img_list)
        result.extend(target_result)
        titles_list.extend(title_list)
    save_text(result)
    save_imgs(imgs_list,titles_list)
    
        
    
if __name__ == "__main__":
    main()
    
